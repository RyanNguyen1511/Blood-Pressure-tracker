package com.tuannguyen.bptracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.List;

public class GraphActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private List<Integer> syslist,dialist,pullist,weilist;
    private GraphView graph;
    LineGraphSeries<DataPoint>series,series1,series2,series3,series4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        mDatabase= FirebaseDatabase.getInstance().getReference().child("Users");
        syslist = new ArrayList<>();
        dialist = new ArrayList<>();
        pullist = new ArrayList<>();
        weilist = new ArrayList<>();

        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("systolic").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    syslist.clear();
                    for(DataSnapshot dss : snapshot.getChildren()){
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        syslist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("diastolic").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    dialist.clear();
                    for(DataSnapshot dss:dataSnapshot.getChildren())
                    {
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        dialist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("pulse").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    pullist.clear();
                    for(DataSnapshot dss:dataSnapshot.getChildren())
                    {
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        pullist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("weight").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    weilist.clear();
                    for(DataSnapshot dss:dataSnapshot.getChildren())
                    {
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        weilist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        graph = findViewById(R.id.graph);


        series = new LineGraphSeries<DataPoint>();
        graph.removeAllSeries();
        graph.setBackgroundColor(Color.rgb(244, 245, 246));
        graph.addSeries(series);
        graph.getGridLabelRenderer().setNumHorizontalLabels(8);

    }

    public void grapSys(View view) {

        series = new LineGraphSeries<DataPoint>();
        graph.removeAllSeries();
        graph.setTitle(" Systolic Data ");
        //Design the line in Graph
        series.setColor(Color.argb(255,11,132,165));
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(17);
        series.setThickness(10);
        series.setAnimated(true);

        int y,x;
        for(int i =0;i< 14;i++){
            series.appendData(new DataPoint(i,syslist.get(i)),true, syslist.get(i));

        }
        graph.addSeries(series);
        Toast.makeText(this,"The graphs length is "+ syslist.size(), Toast.LENGTH_SHORT).show();

    }

    public void grapDia(View view) {
        series = new LineGraphSeries<DataPoint>();
        graph.removeAllSeries();
        graph.setTitle(" Diastolic Data ");
        //Design the line in Graph
        series.setColor(Color.argb(255,246,200,95));
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(17);
        series.setThickness(10);
        series.setAnimated(true);

        double y,x;
        for(int i =0;i< dialist.size();i++){
            x= i;
            y=dialist.get(i);
            series.appendData(new DataPoint(x,y),true, dialist.size());
        }
        graph.addSeries(series);
    }

    public void grapPul(View view) {
        series = new LineGraphSeries<DataPoint>();
        graph.removeAllSeries();
        graph.setTitle(" Pulse Data ");
        //Design the line in Graph
        series.setColor(Color.argb(255,111,78,124));
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(17);
        series.setThickness(10);
        series.setAnimated(true);
        double y,x;
        for(int i =0;i< pullist.size();i++){
            x= i;
            y=pullist.get(i);
            series.appendData(new DataPoint(x,y),true, pullist.size());
        }
        graph.addSeries(series);
    }

    public void grapWeight(View view) {
        series = new LineGraphSeries<DataPoint>();
        graph.removeAllSeries();
        graph.setTitle(" Weight Data ");
        //Design the line in Graph
        series.setColor(Color.argb(255,157,216,102));
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(17);
        series.setThickness(10);
        series.setAnimated(true);

        double y,x;
        for(int i =0;i< weilist.size();i++){
            x= i;
            y=weilist.get(i);
            series.appendData(new DataPoint(x,y),true, weilist.size());
        }
        graph.addSeries(series);
    }

    public void grapAll(View view) {
        series1 = new LineGraphSeries<DataPoint>();
        series2 = new LineGraphSeries<DataPoint>();
        series3 = new LineGraphSeries<DataPoint>();
        series4 = new LineGraphSeries<DataPoint>();

        graph.removeAllSeries();
        graph.setTitle(" Blood Pressure Data ");
        //Design the line in Graph
        series1.setColor(Color.argb(255,11,132,165));
        series1.setDrawDataPoints(true);
        series1.setDataPointsRadius(17);
        series1.setThickness(10);
        series1.setAnimated(true);

        series2.setColor(Color.argb(255,246,200,95));
        series2.setDrawDataPoints(true);
        series2.setDataPointsRadius(17);
        series2.setThickness(10);
        series2.setAnimated(true);

        series3.setColor(Color.argb(255,111,78,124));
        series3.setDrawDataPoints(true);
        series3.setDataPointsRadius(17);
        series3.setThickness(10);
        series3.setAnimated(true);

        series4.setColor(Color.argb(255,157,216,102));
        series4.setDrawDataPoints(true);
        series4.setDataPointsRadius(17);
        series4.setThickness(10);
        series4.setAnimated(true);

        for(int i =0;i< syslist.size();i++){
            series1.appendData(new DataPoint(i,syslist.get(i)),true, syslist.size());
            series2.appendData(new DataPoint(i,dialist.get(i)),true, syslist.size());
            series3.appendData(new DataPoint(i,pullist.get(i)),true, syslist.size());
            series4.appendData(new DataPoint(i,weilist.get(i)),true, syslist.size());
        }
        graph.addSeries(series1);
        graph.addSeries(series2);
        graph.addSeries(series3);
        graph.addSeries(series4);
    }
}