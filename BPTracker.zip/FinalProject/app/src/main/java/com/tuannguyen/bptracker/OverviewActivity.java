package com.tuannguyen.bptracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class OverviewActivity extends AppCompatActivity {
    String header[] = {"ID","MIN","MAX","AVG"};
    private DatabaseReference mDatabase;
    private List<Integer> syslist,dialist,pullist,weilist;

    TextView sysmindata;
    TextView sysmaxdata;
    TextView sysavgdata;
    TextView diamindata;
    TextView diamaxdata;
    TextView diaavgdata;
    TextView pulmindata;
    TextView pulmaxdata;
    TextView pulavgdata;
    TextView weimindata;
    TextView weimaxdata;
    TextView weiavgdata;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_overview);

        mDatabase= FirebaseDatabase.getInstance().getReference().child("Users");
        syslist = new ArrayList<>();
        dialist = new ArrayList<>();
        pullist = new ArrayList<>();
        weilist = new ArrayList<>();

        sysmindata = findViewById(R.id.sysmin);
        sysmaxdata = findViewById(R.id.sysmax);
        sysavgdata = findViewById(R.id.sysavg);
        diamindata = findViewById(R.id.diamin);
        diamaxdata = findViewById(R.id.diamax);
        diaavgdata = findViewById(R.id.diaavg);
        pulmindata = findViewById(R.id.pulmin);
        pulmaxdata = findViewById(R.id.pulmax);
        pulavgdata = findViewById(R.id.pulavg);
        weimindata = findViewById(R.id.weimin);
        weimaxdata = findViewById(R.id.weimax);
        weiavgdata = findViewById(R.id.weiavg);

        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("systolic").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    syslist.clear();
                    for(DataSnapshot dss : snapshot.getChildren()){
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        syslist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("diastolic").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    dialist.clear();
                    for(DataSnapshot dss:dataSnapshot.getChildren())
                    {
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        dialist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("pulse").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    pullist.clear();
                    for(DataSnapshot dss:dataSnapshot.getChildren())
                    {
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        pullist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("weight").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    weilist.clear();
                    for(DataSnapshot dss:dataSnapshot.getChildren())
                    {
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        weilist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }


    public void overview7(View view) {
        if(syslist.size()>=7) {
            // SYSTOLIC
            int sysmin = Integer.MAX_VALUE;
            int sysmax = 0;
            int sysavg = 0;
            int syssum = 0;
            for (int i = 0; i < 7; i++) {
                if (sysmin >= syslist.get(i)) {
                    sysmin = syslist.get(i);
                }
                if (sysmax <= syslist.get(i)) {
                    sysmax = syslist.get(i);
                }
                syssum += syslist.get(i);
            }
            sysavg = syssum / 7;

            // Diastolic
            int diamin = Integer.MAX_VALUE;
            int diamax = 0;
            int diaavg = 0;
            int diasum = 0;
            for (int i = 0; i < 7; i++) {
                if (diamin >= dialist.get(i)) {
                    diamin = dialist.get(i);
                }
                if (diamax <= dialist.get(i)) {
                    diamax = dialist.get(i);
                }
                diasum += dialist.get(i);
            }
            diaavg = diasum / 7;

            // pulstolic
            int pulmin = Integer.MAX_VALUE;
            int pulmax = 0;
            int pulavg = 0;
            int pulsum = 0;
            for (int i = 0; i < 7; i++) {
                if (pulmin >= pullist.get(i)) {
                    pulmin = pullist.get(i);
                }
                if (pulmax <= pullist.get(i)) {
                    pulmax = pullist.get(i);
                }
                pulsum += pullist.get(i);
            }
            pulavg = pulsum / 7;

            // weistolic
            int weimin = Integer.MAX_VALUE;
            int weimax = 0;
            int weiavg = 0;
            int weisum = 0;
            for (int i = 0; i < 7; i++) {
                if (weimin >= weilist.get(i)) {
                    weimin = weilist.get(i);
                }
                if (weimax <= weilist.get(i)) {
                    weimax = weilist.get(i);
                }
                weisum += weilist.get(i);
            }
            weiavg = weisum / 7;

            sysmindata.setText(String.valueOf(sysmin));
            sysmaxdata.setText(String.valueOf(sysmax));
            sysavgdata.setText(String.valueOf(sysavg));
            diamindata.setText(String.valueOf(diamin));
            diamaxdata.setText(String.valueOf(diamax));
            diaavgdata.setText(String.valueOf(diaavg));
            pulmindata.setText(String.valueOf(pulmin));
            pulmaxdata.setText(String.valueOf(pulmax));
            pulavgdata.setText(String.valueOf(pulavg));
            weimindata.setText(String.valueOf(weimin));
            weimaxdata.setText(String.valueOf(weimax));
            weiavgdata.setText(String.valueOf(weiavg));
        }else
            overviewalldata();
    }



    public void overview30(View view) {
        if(syslist.size()>=30){
            int sysmin = Integer.MAX_VALUE;
            int sysmax = 0;
            int sysavg = 0;
            int syssum = 0;
            for (int i = 0; i < 30; i++) {
                if (sysmin >= syslist.get(i)) {
                    sysmin = syslist.get(i);
                }
                if (sysmax <= syslist.get(i)) {
                    sysmax = syslist.get(i);
                }
                syssum += syslist.get(i);
            }
            sysavg = syssum / 30;

            // Diastolic
            int diamin = Integer.MAX_VALUE;
            int diamax = 0;
            int diaavg = 0;
            int diasum = 0;
            for (int i = 0; i < 30; i++) {
                if (diamin >= dialist.get(i)) {
                    diamin = dialist.get(i);
                }
                if (diamax <= dialist.get(i)) {
                    diamax = dialist.get(i);
                }
                diasum += dialist.get(i);
            }
            diaavg = diasum / 30;

            // pulstolic
            int pulmin = Integer.MAX_VALUE;
            int pulmax = 0;
            int pulavg = 0;
            int pulsum = 0;
            for (int i = 0; i < 30; i++) {
                if (pulmin >= pullist.get(i)) {
                    pulmin = pullist.get(i);
                }
                if (pulmax <= pullist.get(i)) {
                    pulmax = pullist.get(i);
                }
                pulsum += pullist.get(i);
            }
            pulavg = pulsum / 30;

            // weistolic
            int weimin = Integer.MAX_VALUE;
            int weimax = 0;
            int weiavg = 0;
            int weisum = 0;
            for (int i = 0; i < 30; i++) {
                if (weimin >= weilist.get(i)) {
                    weimin = weilist.get(i);
                }
                if (weimax <= weilist.get(i)) {
                    weimax = weilist.get(i);
                }
                weisum += weilist.get(i);
            }
            weiavg = weisum / 30;

            sysmindata.setText(String.valueOf(sysmin));
            sysmaxdata.setText(String.valueOf(sysmax));
            sysavgdata.setText(String.valueOf(sysavg));
            diamindata.setText(String.valueOf(diamin));
            diamaxdata.setText(String.valueOf(diamax));
            diaavgdata.setText(String.valueOf(diaavg));
            pulmindata.setText(String.valueOf(pulmin));
            pulmaxdata.setText(String.valueOf(pulmax));
            pulavgdata.setText(String.valueOf(pulavg));
            weimindata.setText(String.valueOf(weimin));
            weimaxdata.setText(String.valueOf(weimax));
            weiavgdata.setText(String.valueOf(weiavg));
        }else
            overviewalldata();
    }

    public void overviewall(View view) {
        // SYSTOLIC
        int sysmin = Integer.MAX_VALUE;
        int sysmax =0;
        int sysavg =0;
        int syssum = 0;
        for (int i =0;i<syslist.size();i++){
            if(sysmin>= syslist.get(i)){
                sysmin = syslist.get(i);
            }
            if(sysmax <=syslist.get(i)){
                sysmax = syslist.get(i);
            }
            syssum += syslist.get(i);
        }
        sysavg = syssum/syslist.size();

        // Diastolic
        int diamin = Integer.MAX_VALUE;
        int diamax =0;
        int diaavg =0;
        int diasum = 0;
        for (int i =0;i<dialist.size();i++){
            if(diamin>= dialist.get(i)){
                diamin = dialist.get(i);
            }
            if(diamax <=dialist.get(i)){
                diamax = dialist.get(i);
            }
            diasum += dialist.get(i);
        }
        diaavg = diasum/dialist.size();

        // pulstolic
        int pulmin = Integer.MAX_VALUE;
        int pulmax =0;
        int pulavg =0;
        int pulsum = 0;
        for (int i =0;i<pullist.size();i++){
            if(pulmin>= pullist.get(i)){
                pulmin = pullist.get(i);
            }
            if(pulmax <=pullist.get(i)){
                pulmax = pullist.get(i);
            }
            pulsum += pullist.get(i);
        }
        pulavg = pulsum/pullist.size();

        // weistolic
        int weimin = Integer.MAX_VALUE;
        int weimax =0;
        int weiavg =0;
        int weisum = 0;
        for (int i =0;i<weilist.size();i++){
            if(weimin>= weilist.get(i)){
                weimin = weilist.get(i);
            }
            if(weimax <=weilist.get(i)){
                weimax = weilist.get(i);
            }
            weisum += weilist.get(i);
        }
        weiavg = weisum/weilist.size();

        sysmindata.setText(String.valueOf(sysmin));
        sysmaxdata.setText(String.valueOf(sysmax));
        sysavgdata.setText(String.valueOf(sysavg));
        diamindata.setText(String.valueOf(diamin));
        diamaxdata.setText(String.valueOf(diamax));
        diaavgdata.setText(String.valueOf(diaavg));
        pulmindata.setText(String.valueOf(pulmin));
        pulmaxdata.setText(String.valueOf(pulmax));
        pulavgdata.setText(String.valueOf(pulavg));
        weimindata.setText(String.valueOf(weimin));
        weimaxdata.setText(String.valueOf(weimax));
        weiavgdata.setText(String.valueOf(weiavg));
    }

    private void overviewalldata() {
        // SYSTOLIC
        int sysmin = Integer.MAX_VALUE;
        int sysmax =0;
        int sysavg =0;
        int syssum = 0;
        for (int i =0;i<syslist.size();i++){
            if(sysmin>= syslist.get(i)){
                sysmin = syslist.get(i);
            }
            if(sysmax <=syslist.get(i)){
                sysmax = syslist.get(i);
            }
            syssum += syslist.get(i);
        }
        sysavg = syssum/syslist.size();

        // Diastolic
        int diamin = Integer.MAX_VALUE;
        int diamax =0;
        int diaavg =0;
        int diasum = 0;
        for (int i =0;i<dialist.size();i++){
            if(diamin>= dialist.get(i)){
                diamin = dialist.get(i);
            }
            if(diamax <=dialist.get(i)){
                diamax = dialist.get(i);
            }
            diasum += dialist.get(i);
        }
        diaavg = diasum/dialist.size();

        // pulstolic
        int pulmin = Integer.MAX_VALUE;
        int pulmax =0;
        int pulavg =0;
        int pulsum = 0;
        for (int i =0;i<pullist.size();i++){
            if(pulmin>= pullist.get(i)){
                pulmin = pullist.get(i);
            }
            if(pulmax <=pullist.get(i)){
                pulmax = pullist.get(i);
            }
            pulsum += pullist.get(i);
        }
        pulavg = pulsum/pullist.size();

        // weistolic
        int weimin = Integer.MAX_VALUE;
        int weimax =0;
        int weiavg =0;
        int weisum = 0;
        for (int i =0;i<weilist.size();i++){
            if(weimin>= weilist.get(i)){
                weimin = weilist.get(i);
            }
            if(weimax <=weilist.get(i)){
                weimax = weilist.get(i);
            }
            weisum += weilist.get(i);
        }
        weiavg = weisum/weilist.size();

        sysmindata.setText(String.valueOf(sysmin));
        sysmaxdata.setText(String.valueOf(sysmax));
        sysavgdata.setText(String.valueOf(sysavg));
        diamindata.setText(String.valueOf(diamin));
        diamaxdata.setText(String.valueOf(diamax));
        diaavgdata.setText(String.valueOf(diaavg));
        pulmindata.setText(String.valueOf(pulmin));
        pulmaxdata.setText(String.valueOf(pulmax));
        pulavgdata.setText(String.valueOf(pulavg));
        weimindata.setText(String.valueOf(weimin));
        weimaxdata.setText(String.valueOf(weimax));
        weiavgdata.setText(String.valueOf(weiavg));
    }
}