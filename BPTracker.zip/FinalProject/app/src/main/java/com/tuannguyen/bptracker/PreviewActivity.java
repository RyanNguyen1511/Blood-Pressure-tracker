package com.tuannguyen.bptracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class PreviewActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private List<Integer> syslist,dialist,pullist,weilist;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> arrayList;
    private ListView lv;
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        lv = findViewById(R.id.list_item);
        arrayList = new ArrayList<>();
        adapter = new ArrayAdapter<String>(this, R.layout.listrow, arrayList);
        lv.setAdapter(adapter);

        mDatabase= FirebaseDatabase.getInstance().getReference().child("Users");
        syslist = new ArrayList<>();
        dialist = new ArrayList<>();
        pullist = new ArrayList<>();
        weilist = new ArrayList<>();


        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("systolic").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    syslist.clear();
                    for(DataSnapshot dss : snapshot.getChildren()){
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        syslist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("diastolic").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    dialist.clear();
                    for(DataSnapshot dss:dataSnapshot.getChildren())
                    {
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        dialist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("pulse").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    pullist.clear();
                    for(DataSnapshot dss:dataSnapshot.getChildren())
                    {
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        pullist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("weight").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    weilist.clear();
                    for(DataSnapshot dss:dataSnapshot.getChildren())
                    {
                        Integer sysData = Integer.parseInt(dss.getValue(String.class));
                        weilist.add(sysData);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });






    }

    public void preview7(View view) {
        arrayList.clear();
        if (syslist.size()>=7){
            for (int i =0; i < 7;i++){
                String data = "Systolic: " + syslist.get(syslist.size()-i-1).toString().trim() + "\n" + "Diastolic: " +
                        dialist.get(syslist.size()-i-1).toString().trim() + "\n" + "Pulse: " +
                        pullist.get(syslist.size()-i-1).toString().trim() + "\n" + "Weight: " +
                        weilist.get(syslist.size()-i-1).toString().trim();
//                String data =pullist.get(i).toString().trim();
                arrayList.add(data);
                adapter.notifyDataSetChanged();
            }
        }else{
            for (int i =0; i < syslist.size();i++){
                String data = "Systolic: " + syslist.get(syslist.size()-i-1).toString().trim() + "\n" + "Diastolic: " +
                        dialist.get(syslist.size()-i-1).toString().trim() + "\n" + "Pulse: " +
                        pullist.get(syslist.size()-i-1).toString().trim() + "\n" + "Weight: " +
                        weilist.get(syslist.size()-i-1).toString().trim();
//                String data =pullist.get(i).toString().trim();
                arrayList.add(data);
                adapter.notifyDataSetChanged();
            }
        }
    }

    public void preview30(View view) {
        arrayList.clear();
        if (syslist.size()>=30){
            for (int i =0; i < 30;i++){
                String data = "Systolic: " + syslist.get(syslist.size()-i-1).toString().trim() + "\n" + "Diastolic: " +
                        dialist.get(syslist.size()-i-1).toString().trim() + "\n" + "Pulse: " +
                        pullist.get(syslist.size()-i-1).toString().trim() + "\n" + "Weight: " +
                        weilist.get(syslist.size()-i-1).toString().trim();
                arrayList.add(data);
                adapter.notifyDataSetChanged();
            }
        }else{
            for (int i =0; i < syslist.size();i++){
                String data = "Systolic: " + syslist.get(syslist.size()-i-1).toString().trim() + "\n" + "Diastolic: " +
                        dialist.get(syslist.size()-i-1).toString().trim() + "\n" + "Pulse: " +
                        pullist.get(syslist.size()-i-1).toString().trim() + "\n" + "Weight: " +
                        weilist.get(syslist.size()-i-1).toString().trim();
                arrayList.add(data);
                adapter.notifyDataSetChanged();
            }
        }
    }

    public void previewAll(View view) {
        arrayList.clear();
        for (int i =0; i < syslist.size();i++){
            String data = "Systolic: " + syslist.get(syslist.size()-i-1).toString().trim() + "\n" + "Diastolic: " +
                    dialist.get(syslist.size()-i-1).toString().trim() + "\n" + "Pulse: " +
                    pullist.get(syslist.size()-i-1).toString().trim() + "\n" + "Weight: " +
                    weilist.get(syslist.size()-i-1).toString().trim();
            arrayList.add(data);
            adapter.notifyDataSetChanged();
        }
    }
}